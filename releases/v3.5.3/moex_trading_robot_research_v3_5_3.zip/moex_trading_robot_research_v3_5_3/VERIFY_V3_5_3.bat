@echo off
setlocal
cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
    set "PYTHON=.venv\Scripts\python.exe"
) else (
    set "PYTHON=python"
)

%PYTHON% -c "import trading_robot; import trading_robot.config_persistence; import trading_robot.portfolio; import trading_robot.diagnostics; assert trading_robot.__version__ == '0.3.5.3'; print('Version:', trading_robot.__version__); print('v3.5.3 modules: OK')"
if errorlevel 1 goto :fail

%PYTHON% -m compileall -q .
if errorlevel 1 goto :fail

%PYTHON% -m pytest -q
if errorlevel 1 goto :fail

echo.
echo Verification v3.5.3 completed successfully.
pause
exit /b 0

:fail
echo.
echo Verification v3.5.3 FAILED.
pause
exit /b 1
