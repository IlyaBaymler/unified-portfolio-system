# Changelog v3.5.3 — Portfolio State & Configuration Safety

## Назначение релиза

Maintenance-релиз после полного Sandbox-цикла v3.5.2. Исправляет смешивание PRIMARY/SHADOW между режимами, добавляет наблюдение за виртуальным портфелем и безопасные инструменты для `UNATTRIBUTED_OPEN_POSITION`.

## Добавлено

### Strategy Profile Store

- отдельные профили `DRY_RUN` и `SANDBOX_EXECUTION`;
- атомарный `strategy_profiles.json`;
- обязательная SHA-256 checksum каждого профиля;
- миграция первого запуска из старого `.env`;
- fail-closed при повреждении или checksum mismatch;
- явный reset с предупреждением;
- блокировка редактирования во время активной сессии;
- события `CONFIG_LOADED`, `CONFIG_CHANGED`, `CONFIG_RESET`, `CONFIG_APPLIED`, `CONFIG_MISMATCH`;
- режим, hash, PRIMARY и SHADOW видны до запуска;
- CLI использует те же DRY_RUN/SANDBOX_EXECUTION-профили и не откатывается к `.env` при execution.

### Virtual Portfolio View

- новая вкладка GUI;
- стоимость портфеля, cash, securities value и P&L;
- позиции нескольких инструментов;
- разрешение ticker/class code по UID, position UID или FIGI через `GetInstrumentBy`;
- фактические и целевые лоты;
- ownership и таймфрейм владельца;
- local/broker pending orders;
- reconciliation status;
- асинхронное и периодическое обновление;
- предупреждение при выходе из GUI после снимка с открытой позицией.

### Ownership Recovery

- строгий precheck счёта, инструмента, таймфрейма, strategy ID, config hash и target lots;
- проверка отсутствия pending orders;
- фраза `ADOPT <ТИКЕР> <ЛОТЫ>`;
- дополнительное подтверждение;
- recovery ID и audit evidence в state;
- поля `ownership_recovered`, `confirmed_lots`, `recovered_at`;
- событие `OWNERSHIP_RECOVERED`.

### Safe Unattributed Close

- закрытие точного количества непривязанных лотов;
- повторное чтение позиции перед intent;
- фраза `CLOSE <ТИКЕР> <ЛОТЫ>`;
- дальнейшее сопровождение стандартной state machine и reconciliation.

### Reconciliation

- периодическая сверка на `already_processed`;
- `PERIODIC_POSITION_BASELINED`;
- `PERIODIC_POSITION_RECONCILED`;
- `PERIODIC_POSITION_MISMATCH`;
- mismatch остаётся активным на следующих heartbeat и не маскируется новой фактической величиной;
- `last_confirmed_current_lots` и `last_confirmed_target_lots` в state/status.

### Circuit Breaker Audit

- `CIRCUIT_OPEN`;
- `CIRCUIT_HALF_OPEN`;
- `CIRCUIT_CLOSED`.

## Исправлено

- случайное переключение PRIMARY/SHADOW между Dry-run и Sandbox;
- повторное использование diagnostic request ID после отката state;
- неоднозначное отображение `MATCH` для непривязанной позиции;
- отсутствие SHADOW-решения в новом session из-за глобальной дедупликации;
- отсутствие периодической сверки при уже обработанной свече;
- повторное перекрытие expected position после внешнего drift;
- `.env`-кнопка GUI теперь сохраняет только подключение, а не скрытое состояние стратегии;
- обновление портфеля после recovery/close запускается после завершения операции.

## Изменено

- package version: `0.3.5.3`;
- state schema: `5`;
- GUI: 7 вкладок;
- экспорт событий: `trading_events_v3_5_3.csv`;
- название: `MOEX Research Robot v3.5.3`.

## Тесты

```text
119 passed
compileall: passed
GUI smoke-test: passed
profile restart/independence smoke-test: passed
```

## Известные ограничения

- реальный счёт не поддерживается;
- один исполнительный инструмент;
- long-only;
- Portfolio View не является ещё многоинструментным allocator;
- отдельный модуль облигационной математики отсутствует;
- редкая задержка системного DNS может превысить requests connect timeout;
- фактический Sandbox-тест новой версии выполняется пользователем со своим токеном.
