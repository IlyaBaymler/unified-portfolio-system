from pathlib import Path

from trading_robot.diagnostics import DiagnosticConfig, SandboxOrderDiagnostics


class FakeDiagnosticAPI:
    def __init__(self) -> None:
        self.current_lots = 0
        self.post_count = 0
        self.orders = {}
        self.last_response_meta = {"tracking_id": "track-1"}

    def find_instrument(self, ticker, class_code):
        return {
            "ticker": ticker,
            "classCode": class_code,
            "uid": "uid-sber",
            "apiTradeAvailableFlag": True,
        }

    @staticmethod
    def instrument_id(instrument):
        return instrument["uid"]

    def get_portfolio(self, account_id):
        if self.current_lots == 0:
            return {"positions": []}
        return {
            "positions": [
                {
                    "instrumentUid": "uid-sber",
                    "quantityLots": {
                        "units": str(self.current_lots),
                        "nano": 0,
                    },
                }
            ]
        }

    @staticmethod
    def position_lots(portfolio, instrument):
        positions = portfolio.get("positions", [])
        return int(positions[0]["quantityLots"]["units"]) if positions else 0

    def get_trading_status(self, instrument_id):
        return {
            "apiTradeAvailableFlag": True,
            "limitOrderAvailableFlag": True,
            "marketOrderAvailableFlag": True,
        }

    @staticmethod
    def best_price_available(status):
        return True

    @staticmethod
    def market_order_available(status):
        return True

    def get_max_lots(self, account_id, instrument_id):
        return {"buyLimits": {"buyMaxMarketLots": "100"}}

    @staticmethod
    def max_buy_lots(response):
        return int(response["buyLimits"]["buyMaxMarketLots"])

    def get_orders(self, account_id):
        return []

    def post_order(
        self,
        account_id,
        instrument_id,
        lots,
        direction,
        *,
        order_id,
        order_type,
        time_in_force,
    ):
        self.post_count += 1
        if order_id not in self.orders:
            delta = lots if direction == "BUY" else -lots
            self.current_lots += delta
            self.orders[order_id] = {
                "orderId": order_id,
                "executionReportStatus": "EXECUTION_REPORT_STATUS_FILL",
                "lotsExecuted": str(lots),
            }
        return self.orders[order_id]

    def get_order_state(self, account_id, order_id, by_request_id=True):
        return self.orders[order_id]


def config(tmp_path: Path) -> DiagnosticConfig:
    return DiagnosticConfig(
        state_file=str(tmp_path / "diagnostic.json"),
        journal_file=str(tmp_path / "events.db"),
        reconcile_delay_seconds=0,
    )


def test_controlled_buy_and_sell_round_trip(tmp_path: Path):
    api = FakeDiagnosticAPI()
    service = SandboxOrderDiagnostics(api, "account-1", config(tmp_path))

    buy = service.execute("BUY")
    assert buy["status"] == "processed"
    assert buy["position_reconciled"] is True
    assert buy["actual_lots_after"] == 1

    sell = service.execute("SELL")
    assert sell["status"] == "processed"
    assert sell["position_reconciled"] is True
    assert sell["actual_lots_after"] == 0
    assert api.post_count == 2


def test_sell_is_blocked_without_a_long_position(tmp_path: Path):
    api = FakeDiagnosticAPI()
    service = SandboxOrderDiagnostics(api, "account-1", config(tmp_path))
    result = service.execute("SELL")
    assert result["status"] == "execution_blocked"
    assert api.post_count == 0


def test_diagnostic_nontransient_rejection_clears_pending(tmp_path: Path):
    from trading_robot.tbank_sandbox import TBankAPIError

    class RejectingDiagnosticAPI(FakeDiagnosticAPI):
        def post_order(self, *args, **kwargs):
            self.post_count += 1
            raise TBankAPIError(
                "invalid diagnostic order",
                status_code=400,
                transient=False,
                service="SandboxService",
                method="PostSandboxOrder",
            )

    api = RejectingDiagnosticAPI()
    service = SandboxOrderDiagnostics(api, "account-1", config(tmp_path))

    result = service.execute("BUY")
    snapshot = service.snapshot()

    assert result["status"] == "submission_failed"
    assert result["pending_order"] is None
    assert snapshot["pending_order"] is None
    assert api.post_count == 1


def test_diagnostic_lost_response_recovers_without_duplicate(tmp_path: Path):
    import pytest
    from trading_robot.tbank_sandbox import TBankAPIError

    class LostResponseDiagnosticAPI(FakeDiagnosticAPI):
        def post_order(
            self,
            account_id,
            instrument_id,
            lots,
            direction,
            *,
            order_id,
            order_type,
            time_in_force,
        ):
            self.post_count += 1
            if order_id not in self.orders:
                self.current_lots += lots if direction == "BUY" else -lots
                self.orders[order_id] = {
                    "orderId": order_id,
                    "executionReportStatus": "EXECUTION_REPORT_STATUS_FILL",
                    "lotsExecuted": str(lots),
                }
            raise TBankAPIError(
                "response lost",
                transient=True,
                service="SandboxService",
                method="PostSandboxOrder",
            )

    api = LostResponseDiagnosticAPI()
    service = SandboxOrderDiagnostics(api, "account-1", config(tmp_path))

    with pytest.raises(TBankAPIError):
        service.execute("BUY")
    recovered = service.recover_pending()

    assert recovered["status"] == "processed"
    assert recovered["position_reconciled"] is True
    assert api.post_count == 1


def test_independent_diagnostic_actions_use_unique_request_ids(tmp_path: Path):
    api = FakeDiagnosticAPI()
    service = SandboxOrderDiagnostics(api, "account-1", config(tmp_path))
    first = service.execute("BUY")
    second = service.execute("SELL")
    third = service.execute("BUY")
    assert len({first["order_id"], second["order_id"], third["order_id"]}) == 3


def test_close_unattributed_position_sells_exact_quantity(tmp_path: Path):
    api = FakeDiagnosticAPI()
    api.current_lots = 3
    service = SandboxOrderDiagnostics(api, "account-1", config(tmp_path))
    result = service.close_unattributed_position(
        expected_lots=3,
        confirmation_text="CLOSE SBER 3",
    )
    assert result["status"] == "processed"
    assert result["requested_lots"] == 3
    assert result["actual_lots_after"] == 0
    assert result["position_reconciled"] is True
    assert result["purpose"] == "unattributed-position-close"


def test_close_unattributed_position_rechecks_quantity(tmp_path: Path):
    api = FakeDiagnosticAPI()
    api.current_lots = 2
    service = SandboxOrderDiagnostics(api, "account-1", config(tmp_path))
    result = service.close_unattributed_position(
        expected_lots=3,
        confirmation_text="CLOSE SBER 3",
    )
    assert result["status"] == "execution_blocked"
    assert api.post_count == 0
