from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
import logging
from pathlib import Path
import time
from typing import Any
from uuid import uuid4

from .journal import EventJournal, JournalEvent
from .orders import (
    OrderLifecycle,
    executed_lots,
    is_terminal_order_status,
    lifecycle_for_status,
    normalize_execution_status,
    signed_lot_delta,
    transition_intent,
)
from .state_persistence import atomic_write_json
from .tbank_sandbox import TBankAPIError, TBankSandboxClient


logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class DiagnosticConfig:
    ticker: str = "SBER"
    class_code: str = "TQBR"
    lots: int = 1
    state_file: str = "sandbox_diagnostic_state.json"
    journal_file: str = ""
    order_type: str = "BESTPRICE"
    time_in_force: str = "FILL_AND_KILL"
    reconcile_attempts: int = 3
    reconcile_delay_seconds: float = 0.5

    def __post_init__(self) -> None:
        if self.lots != 1:
            raise ValueError(
                "The v3.4 diagnostic is intentionally restricted to exactly 1 lot."
            )
        if self.order_type.upper() not in {"MARKET", "BESTPRICE"}:
            raise ValueError("Unsupported diagnostic order type.")
        if self.time_in_force.upper() not in {
            "DAY",
            "FILL_AND_KILL",
            "FILL_OR_KILL",
        }:
            raise ValueError("Unsupported diagnostic time in force.")
        if self.reconcile_attempts < 1:
            raise ValueError("reconcile_attempts must be positive.")
        if self.reconcile_delay_seconds < 0:
            raise ValueError("reconcile_delay_seconds must not be negative.")


class SandboxOrderDiagnostics:
    """Controlled one-lot order diagnostic independent of strategy signals."""

    STATE_VERSION = 1

    def __init__(
        self,
        api: TBankSandboxClient,
        account_id: str,
        config: DiagnosticConfig,
    ) -> None:
        self.api = api
        self.account_id = str(account_id)
        self.config = config
        self.instrument = api.find_instrument(config.ticker, config.class_code)
        self.instrument_id = api.instrument_id(self.instrument)
        self.state_path = Path(config.state_file)
        journal_path = (
            Path(config.journal_file)
            if config.journal_file
            else self.state_path.with_name("trading_events.db")
        )
        self.journal = EventJournal(journal_path)
        self._active_run_id: str | None = None
        self.state_key = "|".join(
            [
                self.account_id,
                self.instrument_id,
                "manual-one-lot-diagnostic",
            ]
        )

    def snapshot(self) -> dict[str, Any]:
        portfolio = self.api.get_portfolio(self.account_id)
        current_lots = self.api.position_lots(portfolio, self.instrument)
        trading_status = self.api.get_trading_status(self.instrument_id)
        max_lots = self.api.get_max_lots(self.account_id, self.instrument_id)
        active_orders = self.api.get_orders(self.account_id)
        root = self._load_state()
        state = root.setdefault("diagnostics", {}).setdefault(self.state_key, {})
        return {
            "status": "ready",
            "ticker": self.config.ticker,
            "instrument_id": self.instrument_id,
            "account_id": self.account_id,
            "current_lots": current_lots,
            "broker_max_buy_lots": self.api.max_buy_lots(max_lots),
            "trading_status": trading_status,
            "best_price_available": self.api.best_price_available(trading_status),
            "market_order_available": self.api.market_order_available(trading_status),
            "active_orders": active_orders,
            "pending_order": state.get("pending_order"),
            "last_response_meta": self.api.last_response_meta,
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }

    def execute(self, direction: str) -> dict[str, Any]:
        """Run the original explicitly confirmed one-lot diagnostic."""
        return self._execute_order(
            direction,
            lots=1,
            purpose="manual-one-lot-diagnostic",
        )

    def close_unattributed_position(
        self,
        *,
        expected_lots: int,
        confirmation_text: str,
    ) -> dict[str, Any]:
        """Close an explicitly confirmed unattributed long Sandbox position.

        The broker quantity is re-read immediately before the intent is saved.
        A random request id is persisted before submission, so this operation is
        both unique across independent manual actions and recoverable after a
        lost response.
        """
        lots = int(expected_lots)
        if lots < 1:
            raise ValueError("expected_lots must be positive.")
        phrase = f"CLOSE {self.config.ticker.upper()} {lots}"
        if confirmation_text.strip().upper() != phrase:
            raise ValueError(f"Confirmation mismatch. Enter exactly: {phrase}")
        return self._execute_order(
            "SELL",
            lots=lots,
            purpose="unattributed-position-close",
            require_exact_current_lots=lots,
        )

    def _execute_order(
        self,
        direction: str,
        *,
        lots: int,
        purpose: str,
        require_exact_current_lots: int | None = None,
    ) -> dict[str, Any]:
        direction = direction.strip().upper()
        if direction not in {"BUY", "SELL"}:
            raise ValueError("direction must be BUY or SELL.")
        lots = int(lots)
        if lots < 1:
            raise ValueError("lots must be positive.")
        run_id = str(uuid4())
        self._active_run_id = run_id
        root = self._load_state()
        state = root.setdefault("diagnostics", {}).setdefault(self.state_key, {})

        if state.get("pending_order"):
            recovered = self.recover_pending(run_id=run_id)
            root = self._load_state()
            state = root.setdefault("diagnostics", {}).setdefault(
                self.state_key, {}
            )
            if state.get("pending_order"):
                return {
                    "status": "order_pending",
                    "message": (
                        "Previous diagnostic order is unresolved. New order blocked."
                    ),
                    "recovery": recovered,
                    "pending_order": state.get("pending_order"),
                    "run_id": run_id,
                }

        snapshot = self.snapshot()
        current_lots = int(snapshot["current_lots"])
        if (
            require_exact_current_lots is not None
            and current_lots != int(require_exact_current_lots)
        ):
            return {
                **snapshot,
                "status": "execution_blocked",
                "direction": direction,
                "reason": (
                    "Broker position changed before the recovery close: "
                    f"expected {require_exact_current_lots}, actual {current_lots}."
                ),
                "run_id": run_id,
            }
        trading_status = snapshot["trading_status"]
        if self.config.order_type.upper() == "MARKET":
            available = self.api.market_order_available(trading_status)
        else:
            available = self.api.best_price_available(trading_status)
        if not available:
            return {
                **snapshot,
                "status": "execution_blocked",
                "direction": direction,
                "reason": "Instrument is not available for the selected order type.",
                "run_id": run_id,
            }
        if direction == "BUY":
            maximum = snapshot.get("broker_max_buy_lots")
            if maximum is not None and int(maximum) < lots:
                return {
                    **snapshot,
                    "status": "execution_blocked",
                    "direction": direction,
                    "reason": "Broker reports insufficient buy capacity.",
                    "run_id": run_id,
                }
        if direction == "SELL" and current_lots < lots:
            return {
                **snapshot,
                "status": "execution_blocked",
                "direction": direction,
                "reason": "There are not enough long lots available to sell.",
                "run_id": run_id,
            }

        sequence = int(state.get("sequence", 0)) + 1
        order_id = self._order_id(sequence, direction)
        intent: dict[str, Any] = {
            "order_id": order_id,
            "run_id": run_id,
            "sequence": sequence,
            "action": direction,
            "lots": lots,
            "current_lots_before": current_lots,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "order_type": self.config.order_type,
            "time_in_force": self.config.time_in_force,
            "diagnostic": True,
            "purpose": purpose,
        }
        transition_intent(intent, OrderLifecycle.PRECHECK_PASSED)
        transition_intent(intent, OrderLifecycle.INTENT_SAVED)
        state["pending_order"] = intent
        state["sequence"] = sequence
        self._save_state(root)
        self._record_transition(intent, run_id)

        transition_intent(
            intent,
            OrderLifecycle.ORDER_SUBMITTED,
            details={"submission_attempted": True},
        )
        state["pending_order"] = intent
        self._save_state(root)
        self._record_transition(intent, run_id)

        try:
            response = self.api.post_order(
                self.account_id,
                self.instrument_id,
                lots,
                direction,
                order_id=order_id,
                order_type=self.config.order_type,
                time_in_force=self.config.time_in_force,
            )
        except TBankAPIError as exc:
            if exc.transient or exc.status_code is None or exc.status_code < 400:
                raise
            transition_intent(
                intent,
                OrderLifecycle.SUBMISSION_FAILED,
                details={
                    "accepted": False,
                    "submission_error": str(exc),
                    "status_code": exc.status_code,
                    "tracking_id": exc.tracking_id,
                },
            )
            self._record_transition(intent, run_id, {"api_error": exc.details})
            state.pop("pending_order", None)
            state["last_order_id"] = order_id
            state["last_action"] = direction
            state["last_failure_at"] = datetime.now(timezone.utc).isoformat()
            self._save_state(root)
            return {
                "status": "submission_failed",
                "ticker": self.config.ticker,
                "instrument_id": self.instrument_id,
                "account_id": self.account_id,
                "direction": direction,
                "requested_lots": lots,
                "executed_lots": 0,
                "order_id": order_id,
                "order_status": "REJECTED",
                "order_lifecycle_state": intent.get("lifecycle_state"),
                "position_reconciled": True,
                "pending_order": None,
                "error": str(exc),
                "api_status_code": exc.status_code,
                "tracking_id": exc.tracking_id,
                "run_id": run_id,
                "purpose": purpose,
            }
        transition_intent(
            intent,
            OrderLifecycle.ORDER_ACCEPTED,
            details={"accepted": True},
        )
        state["pending_order"] = intent
        self._save_state(root)
        self._record_transition(intent, run_id, {"order_response": response})

        order_state = self.api.get_order_state(
            self.account_id,
            order_id,
            by_request_id=True,
        )
        result = self._finalise_order(
            root,
            state,
            intent,
            order_state,
            run_id=run_id,
            response=response,
        )
        result["purpose"] = purpose
        return result

    def recover_pending(self, *, run_id: str | None = None) -> dict[str, Any]:
        run_id = run_id or str(uuid4())
        self._active_run_id = run_id
        root = self._load_state()
        state = root.setdefault("diagnostics", {}).setdefault(self.state_key, {})
        intent = state.get("pending_order")
        if not intent:
            return {
                "status": "no_pending_order",
                "ticker": self.config.ticker,
                "run_id": run_id,
            }
        order_id = str(intent.get("order_id", ""))
        if not order_id:
            raise RuntimeError("Diagnostic pending order has no order_id.")
        try:
            order_state = self.api.get_order_state(
                self.account_id,
                order_id,
                by_request_id=True,
            )
        except TBankAPIError as exc:
            if exc.status_code != 404:
                raise
            # Same orderId makes this retry idempotent. The saved intent proves
            # that this diagnostic action had been explicitly confirmed.
            try:
                response = self.api.post_order(
                    self.account_id,
                    self.instrument_id,
                    int(intent.get("lots", 1)),
                    str(intent["action"]),
                    order_id=order_id,
                    order_type=str(
                        intent.get("order_type", self.config.order_type)
                    ),
                    time_in_force=str(
                        intent.get("time_in_force", self.config.time_in_force)
                    ),
                )
            except TBankAPIError as submit_error:
                if (
                    submit_error.transient
                    or submit_error.status_code is None
                    or submit_error.status_code < 400
                ):
                    raise
                transition_intent(
                    intent,
                    OrderLifecycle.SUBMISSION_FAILED,
                    details={
                        "accepted": False,
                        "submission_error": str(submit_error),
                        "status_code": submit_error.status_code,
                        "tracking_id": submit_error.tracking_id,
                    },
                )
                self._record_transition(
                    intent,
                    run_id,
                    {"api_error": submit_error.details, "recovery": True},
                )
                state.pop("pending_order", None)
                state["last_order_id"] = order_id
                state["last_action"] = intent.get("action")
                state["last_failure_at"] = datetime.now(timezone.utc).isoformat()
                self._save_state(root)
                return {
                    "status": "submission_failed",
                    "ticker": self.config.ticker,
                    "instrument_id": self.instrument_id,
                    "account_id": self.account_id,
                    "direction": intent.get("action"),
                    "requested_lots": int(intent.get("lots", 1)),
                    "executed_lots": 0,
                    "order_id": order_id,
                    "order_status": "REJECTED",
                    "order_lifecycle_state": intent.get("lifecycle_state"),
                    "position_reconciled": True,
                    "pending_order": None,
                    "error": str(submit_error),
                    "api_status_code": submit_error.status_code,
                    "tracking_id": submit_error.tracking_id,
                    "run_id": run_id,
                }
            order_state = self.api.get_order_state(
                self.account_id,
                order_id,
                by_request_id=True,
            )
            order_state = {**order_state, "recoveredByResubmit": True}
            self._record_transition(intent, run_id, {"order_response": response})
        return self._finalise_order(
            root,
            state,
            intent,
            order_state,
            run_id=run_id,
            response=None,
        )

    def _finalise_order(
        self,
        root: dict[str, Any],
        state: dict[str, Any],
        intent: dict[str, Any],
        order_state: dict[str, Any],
        *,
        run_id: str,
        response: dict[str, Any] | None,
    ) -> dict[str, Any]:
        status = normalize_execution_status(order_state)
        filled = executed_lots(order_state)
        transition_intent(
            intent,
            lifecycle_for_status(status),
            details={
                "last_known_status": status,
                "executed_lots": filled,
            },
        )
        state["pending_order"] = intent
        self._save_state(root)
        self._record_transition(intent, run_id, {"order_state": order_state})

        actual_after: int | None = None
        expected_after = int(intent.get("current_lots_before", 0)) + signed_lot_delta(
            str(intent["action"]),
            filled,
        )
        reconciled = False
        attempts_used = 0
        if is_terminal_order_status(
            status,
            str(intent.get("time_in_force", self.config.time_in_force)),
        ):
            reconciled, actual_after, attempts_used = self._reconcile(expected_after)
            if reconciled:
                transition_intent(
                    intent,
                    OrderLifecycle.PORTFOLIO_RECONCILED,
                    details={
                        "expected_lots_after": expected_after,
                        "actual_lots_after": actual_after,
                    },
                )
                self._record_transition(intent, run_id)
                state.pop("pending_order", None)
                state["last_order_id"] = intent["order_id"]
                state["last_action"] = intent["action"]
                state["last_reconciled_at"] = datetime.now(
                    timezone.utc
                ).isoformat()
            else:
                transition_intent(
                    intent,
                    OrderLifecycle.RECONCILIATION_REQUIRED,
                    details={
                        "expected_lots_after": expected_after,
                        "actual_lots_after": actual_after,
                    },
                )
                state["pending_order"] = intent
                self._record_transition(intent, run_id)
        self._save_state(root)

        result = {
            "status": "processed" if reconciled else "order_pending",
            "ticker": self.config.ticker,
            "instrument_id": self.instrument_id,
            "account_id": self.account_id,
            "direction": intent["action"],
            "requested_lots": int(intent.get("lots", 1)),
            "executed_lots": filled,
            "order_id": intent["order_id"],
            "order_status": status,
            "order_lifecycle_state": intent.get("lifecycle_state"),
            "expected_lots_after": expected_after,
            "actual_lots_after": actual_after,
            "position_reconciled": reconciled,
            "reconcile_attempts_used": attempts_used,
            "pending_order": state.get("pending_order"),
            "order_response": response,
            "order_state": order_state,
            "run_id": run_id,
            "last_response_meta": self.api.last_response_meta,
        }
        self._record_event(
            JournalEvent(
                category="diagnostic",
                event_type=result["status"],
                severity="INFO" if reconciled else "WARNING",
                run_id=run_id,
                account_id=self.account_id,
                instrument_id=self.instrument_id,
                ticker=self.config.ticker,
                order_id=intent["order_id"],
                payload={
                    key: value
                    for key, value in result.items()
                    if key not in {"order_response", "order_state"}
                },
            )
        )
        return result

    def _reconcile(self, expected_lots: int) -> tuple[bool, int | None, int]:
        actual: int | None = None
        attempts = 0
        for attempts in range(1, self.config.reconcile_attempts + 1):
            portfolio = self.api.get_portfolio(self.account_id)
            actual = self.api.position_lots(portfolio, self.instrument)
            if actual == expected_lots:
                return True, actual, attempts
            if (
                attempts < self.config.reconcile_attempts
                and self.config.reconcile_delay_seconds > 0
            ):
                time.sleep(self.config.reconcile_delay_seconds)
        return False, actual, attempts

    def _order_id(self, sequence: int, direction: str) -> str:
        # Manual diagnostic actions are independent operator commands. A fresh
        # UUID prevents reuse after a state rollback or a copied installation.
        # The generated value is persisted before submission, so recovery still
        # uses exactly the same request id after a lost response.
        del sequence, direction
        return str(uuid4())

    def _load_state(self) -> dict[str, Any]:
        if not self.state_path.exists():
            return {"version": self.STATE_VERSION, "diagnostics": {}}
        try:
            root = json.loads(self.state_path.read_text(encoding="utf-8"))
            if not isinstance(root, dict):
                raise ValueError("Diagnostic state root must be an object.")
            root.setdefault("version", self.STATE_VERSION)
            root.setdefault("diagnostics", {})
            return root
        except (OSError, json.JSONDecodeError, ValueError):
            raise RuntimeError(
                "Diagnostic state file is unreadable. Do not delete it until "
                "the broker confirms there is no unresolved diagnostic order."
            )

    def _handle_state_persistence_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> None:
        severity = {
            "STATE_SAVE_RETRY": "WARNING",
            "STATE_SAVE_RECOVERED": "INFO",
            "STATE_SAVE_FAILED": "ERROR",
        }.get(event_type, "INFO")
        self._record_event(
            JournalEvent(
                category="state",
                event_type=event_type,
                severity=severity,
                run_id=self._active_run_id,
                account_id=self.account_id,
                instrument_id=self.instrument_id,
                ticker=self.config.ticker,
                mode="DIAGNOSTIC",
                status=event_type.lower(),
                payload=payload,
            )
        )
        message = (
            f"{event_type} diagnostic run={str(self._active_run_id or '')[:8]} "
            f"attempt={payload.get('attempt_count') or payload.get('attempt')} "
            f"error={payload.get('error', '—')}"
        )
        if severity == "ERROR":
            logger.error(message)
        elif severity == "WARNING":
            logger.warning(message)
        else:
            logger.info(message)

    def _save_state(self, state: dict[str, Any]) -> None:
        state["version"] = self.STATE_VERSION
        atomic_write_json(
            self.state_path,
            state,
            event_callback=self._handle_state_persistence_event,
        )

    def _record_transition(
        self,
        intent: dict[str, Any],
        run_id: str,
        extra: dict[str, Any] | None = None,
    ) -> None:
        lifecycle = str(intent.get("lifecycle_state", "UNKNOWN"))
        severity = (
            "ERROR"
            if lifecycle == str(OrderLifecycle.RECONCILIATION_REQUIRED)
            else "WARNING"
            if lifecycle in {
                str(OrderLifecycle.SUBMISSION_FAILED),
                str(OrderLifecycle.REJECTED),
                str(OrderLifecycle.CANCELLED),
            }
            else "INFO"
        )
        self._record_event(
            JournalEvent(
                category="diagnostic_order",
                event_type=lifecycle,
                severity=severity,
                run_id=run_id,
                account_id=self.account_id,
                instrument_id=self.instrument_id,
                ticker=self.config.ticker,
                order_id=intent.get("order_id"),
                payload={
                    "action": intent.get("action"),
                    "lots": intent.get("lots"),
                    "current_lots_before": intent.get("current_lots_before"),
                    "executed_lots": intent.get("executed_lots"),
                    "expected_lots_after": intent.get("expected_lots_after"),
                    "actual_lots_after": intent.get("actual_lots_after"),
                    "last_known_status": intent.get("last_known_status"),
                    **(extra or {}),
                },
            )
        )

    def _record_event(self, event: JournalEvent) -> None:
        try:
            self.journal.record(event)
        except Exception:
            logger.exception("Failed to write diagnostic event journal.")
