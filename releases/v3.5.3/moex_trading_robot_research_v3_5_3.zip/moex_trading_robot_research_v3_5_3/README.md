# MOEX Trading Robot — Research Edition v3.5.3

Версия **v3.5.3 Portfolio State & Configuration Safety** развивает проверенный Sandbox-исполнитель v3.5.2 в сторону единой системы управления портфелем. Основные изменения: отдельный интерфейс виртуального портфеля, независимые профили стратегий для Dry-run и Sandbox Execution, контролируемое восстановление ownership, периодическая сверка позиции и более прозрачное состояние circuit breaker.

> Программа предназначена для исследований и T-Invest Sandbox. В коде отсутствует маршрут выставления заявок на реальном счёте.

## Что уже умеет система

- загружать завершённые свечи T-Invest;
- рассчитывать PRIMARY и SHADOW на одном наборе данных;
- поддерживать SMA с гистерезисом, Donchian + ATR и трендовый ансамбль;
- исполнять только решение PRIMARY;
- сохранять intent до отправки заявки;
- восстанавливать неоднозначную заявку по тому же request ID;
- сверять позицию после исполнения;
- блокировать смену стратегии при открытой позиции;
- переживать временные сетевые ошибки и открывать circuit breaker;
- вести компактный и подробный журналы, а также SQLite-аудит;
- показывать текущий виртуальный портфель и ownership позиций.

## Главное в v3.5.3

### 1. Раздельные профили DRY_RUN и SANDBOX_EXECUTION

GUI больше не использует одно общее состояние PRIMARY/SHADOW для двух режимов. Торговые параметры хранятся атомарно в:

```text
strategy_profiles.json
```

В файле находятся два независимых профиля:

```text
DRY_RUN
SANDBOX_EXECUTION
```

Для каждого сохраняются:

- тикер, class code и таймфрейм;
- PRIMARY и набор SHADOW;
- все параметры стратегий;
- лимит лотов и параметры volatility targeting;
- интервалы опроса, reconciliation и circuit breaker;
- сетевые timeout;
- контрольная SHA-256-сумма конфигурации.

При повреждении файла, отсутствии checksum или её несовпадении исполнение блокируется. Тихого возврата к стратегии по умолчанию нет. В журнал записываются события:

```text
CONFIG_LOADED
CONFIG_CHANGED
CONFIG_RESET
CONFIG_APPLIED
CONFIG_MISMATCH
```

Во время активной сессии поля конфигурации заблокированы. Перед Sandbox Execution программа показывает фактически применяемые PRIMARY, SHADOW, таймфрейм, лимит позиции и сокращённый profile hash.

`.env` теперь используется GUI для токена, счёта и подключения. GUI и CLI читают торговую конфигурацию из `strategy_profiles.json`; `ROBOT_*` применяются только при одноразовой миграции первого DRY_RUN. CLI Sandbox Execution не возвращается к `.env` при отсутствующем профиле.

### 2. Вкладка «Виртуальный портфель»

Новая вкладка показывает:

- стоимость портфеля;
- денежный остаток RUB;
- стоимость ценных бумаг;
- ожидаемый P&L;
- фактические и целевые лоты;
- среднюю и текущую цену;
- владельца позиции и его таймфрейм;
- локальные и брокерские pending orders;
- статус reconciliation;
- непривязанные позиции;
- время последнего обновления.

Данные получает `PortfolioManager`; GUI только отображает подготовленную модель и не выполняет портфельные расчёты. Если брокерская позиция содержит только UID/position UID/FIGI, метаданные инструмента разрешаются через `InstrumentsService/GetInstrumentBy` и кэшируются.

### 3. Ownership recovery

Для позиции `UNATTRIBUTED` доступны два безопасных пути.

**Восстановление владельца** разрешается только при совпадении:

- Sandbox-счёта;
- инструмента;
- PRIMARY-стратегии;
- полного config hash;
- таймфрейма;
- текущего количества лотов;
- сохранённого решения PRIMARY и его `target_lots`;
- отсутствия локальных и брокерских активных заявок.

Требуются флажок, фраза:

```text
ADOPT <ТИКЕР> <ЛОТЫ>
```

и дополнительное подтверждение. В state сохраняются recovery ID, время, доказательство решения и подтверждённое количество.

**Безопасное закрытие** используется, когда доказательств ownership нет. Перед продажей количество повторно читается у брокера. Требуется фраза:

```text
CLOSE <ТИКЕР> <ЛОТЫ>
```

### 4. Периодическая reconciliation

Sandbox-исполнитель теперь сверяет позицию не только на новой свече и после заявки, но и на heartbeat уже обработанной свечи. Интервал задаётся:

```text
ROBOT_PORTFOLIO_RECONCILE_INTERVAL_SECONDS=900
```

При внешнем или ручном изменении позиции возникает:

```text
position_mismatch
PERIODIC_POSITION_MISMATCH
```

Новые поручения блокируются. Ожидаемая позиция не перезаписывается фактической после mismatch, поэтому расхождение не исчезает на следующей проверке.

### 5. Явные переходы circuit breaker

В SQLite появились события:

```text
CIRCUIT_OPEN
CIRCUIT_HALF_OPEN
CIRCUIT_CLOSED
```

Они позволяют проверить полный путь восстановления без догадок по косвенным полям.

### 6. Уникальные ID диагностических операций

Каждая новая ручная диагностическая заявка получает случайный UUID. Это предотвращает ошибку повторного request ID после отката или копирования диагностического state-файла. ID всё равно сохраняется до отправки, поэтому потерянный ответ восстанавливается без дублирования.

## Архитектура

```text
Market Data
→ Strategy Engine
→ PRIMARY / SHADOW decisions
→ ownership guard
→ Execution Engine
→ T-Invest Sandbox
→ Portfolio Reconciliation
→ Portfolio View / Event Journal
```

Основные модули:

```text
trading_robot/
├── bot.py                 исполнитель и recovery
├── strategy.py            общее ядро стратегий
├── strategy_runtime.py    PRIMARY/SHADOW решения
├── config_persistence.py  профили режимов
├── portfolio.py           снимок портфеля и ownership recovery
├── diagnostics.py         контролируемые Sandbox-заявки
├── state_persistence.py   атомарная запись state
├── journal.py             SQLite-аудит
└── tbank_sandbox.py       Sandbox REST adapter и metadata resolver
```

## Входные данные и конфигурация

### `.env`

Содержит секреты и параметры подключения:

```text
TBANK_SANDBOX_TOKEN
TBANK_SANDBOX_ACCOUNT_ID
TBANK_CA_BUNDLE
TBANK_CONNECT_TIMEOUT_SECONDS
TBANK_READ_TIMEOUT_SECONDS
```

Не публикуйте `.env`.

### `strategy_profiles.json`

Создаётся автоматически рядом с программой. Это JSON schema v1 с двумя режимами и checksum. Файл не содержит токен и ID счёта.

### `robot_state.json`

State schema v5. Содержит:

- обработанные свечи;
- решения стратегий;
- pending order;
- состояние circuit breaker;
- активного владельца позиции;
- последнюю подтверждённую и ожидаемую позицию;
- время периодической reconciliation.

Не удаляйте state при открытой позиции или неопределённой заявке.

## Результаты и журналы

```text
robot_gui.log       компактный операторский журнал
robot_debug.log     полный диагностический журнал
trading_events.db   структурированный SQLite-аудит
```

Экспорт вкладки событий создаёт CSV, например:

```text
trading_events_v3_5_3.csv
```

Категории включают:

```text
session, cycle, strategy, strategy_comparison, decision,
order, portfolio, configuration, resilience, state,
api, performance, incident, diagnostic_order
```

## Установка в Windows

Требования:

- Windows 10/11;
- Python 3.11 или новее;
- доступ к T-Invest Sandbox;
- Sandbox API-токен.

Первый запуск:

```text
install_and_run_gui.bat
```

Последующие запуски:

```text
run_gui.bat
```

Проверка установки:

```text
VERIFY_V3_5_3.bat
```

## Обновление с v3.5.2

1. Остановите DRY-RUN и Sandbox Execution.
2. Закройте GUI.
3. Сделайте резервные копии:

```text
.env
robot_state.json
sandbox_diagnostic_state.json
strategy_profiles.json   # если уже появился после пробной установки
trading_events.db
```

4. Распакуйте hotfix поверх папки v3.5.2.
5. Запустите `VERIFY_V3_5_3.bat`.
6. Запустите GUI.
7. Проверьте оба профиля до разрешения исполнения.

Подробности: `UPDATE_TO_V3_5_3.md`.

## Минимальный тестовый сценарий

### A. Профили

1. В DRY_RUN выберите PRIMARY=SMA и SHADOW=Donchian.
2. Сохраните профиль.
3. В SANDBOX_EXECUTION выберите PRIMARY=Donchian и SHADOW=Ensemble.
4. Сохраните профиль.
5. Перезапустите GUI.
6. Переключите режимы и подтвердите, что настройки независимы.

### B. Portfolio View

1. Обновите список Sandbox-счетов.
2. Откройте «Виртуальный портфель».
3. Нажмите «Обновить портфель».
4. Сравните количество лотов с Sandbox-портфелем.
5. Проверьте ownership, target и reconciliation.

### C. Dry-run

```text
SBER / TQBR
1 час
PRIMARY: SMA 20/50, гистерезис 0,2%
SHADOW: Donchian и Ensemble
максимум: 1 лот
```

Ожидается `WOULD_BUY`, `WOULD_SELL` или `HOLD`, но:

```text
order_was_sent = false
```

### D. Sandbox

После успешного dry-run и проверки профиля:

1. включите разрешение тестовых заявок;
2. введите `SANDBOX`;
3. подтвердите конфигурацию;
4. разрешите максимум один лот;
5. проверьте `FILLED → PORTFOLIO_RECONCILED`.

Полный план: `V3_5_3_ACCEPTANCE_TEST_PLAN_RU.md`.

## Проверка сборки

На момент сборки выполнено:

```text
Python compileall: успешно
119 unit/integration tests: успешно
GUI smoke-test: успешно
GUI profile restart/independence: успешно
```

Покрыты:

- независимые профили и checksum;
- fail-closed при повреждённом профиле;
- явное восстановление повреждённого profile store;
- пустой и многоинструментный портфель;
- ownership recovery и его блокировки;
- безопасное закрытие непривязанной позиции;
- уникальные diagnostic request IDs;
- периодическая reconciliation и устойчивый mismatch;
- `OPEN → HALF_OPEN → CLOSED`;
- state persistence и восстановление заявок.

## Известные ограничения

- только T-Invest Sandbox;
- один исполняемый инструмент на экземпляр робота;
- long-only;
- Portfolio View уже показывает несколько инструментов, но Portfolio Manager ещё не распределяет капитал между ними;
- облигационная стоимость и НКД пока не имеют отдельного расчётного модуля;
- SHADOW не может отправлять заявки;
- вывод средств не автоматизирован;
- DNS-вызов операционной системы в редком случае может превысить настроенный connect timeout;
- ownership recovery требует сохранённого совместимого решения; без доказательства позицию следует контролируемо закрыть;
- реальный счёт не поддерживается.

## Безопасность

Никогда не добавляйте в GitHub или диагностический архив:

```text
.env
API-токен
Authorization header
ID реального счёта
```

Runtime-файлы также должны оставаться локальными:

```text
robot_state.json
sandbox_diagnostic_state.json
strategy_profiles.json
trading_events.db
robot_gui.log
robot_debug.log
```

## Следующий этап

После burn-in v3.5.3 следующий крупный релиз — **v3.6 Risk Engine**:

- бюджет риска на позицию;
- ATR-based sizing;
- лимиты капитала;
- дневной и недельный loss limit;
- kill switch;
- подготовка к глобальному Portfolio Manager.
