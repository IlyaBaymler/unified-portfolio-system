# Обновление v3.5.2 → v3.5.3

## Перед обновлением

1. Остановите DRY-RUN и Sandbox Execution.
2. Закройте GUI.
3. Убедитесь, что нет неизвестного `pending_order`.
4. Создайте резервную копию:

```text
.env
robot_state.json
sandbox_diagnostic_state.json
trading_events.db
robot_gui.log
robot_debug.log
```

Если ранее тестировался v3.5.3, сохраните также:

```text
strategy_profiles.json
```

## Установка hotfix

1. Распакуйте содержимое `moex_trading_robot_v3_5_3_hotfix.zip` непосредственно в папку установленной v3.5.2.
2. Подтвердите замену файлов.
3. Не создавайте лишнюю вложенную папку.

Правильно:

```text
папка_робота\
    desktop_gui.py
    VERIFY_V3_5_3.bat
    trading_robot\
        bot.py
        portfolio.py
```

## Runtime-файлы

Hotfix не содержит и не заменяет:

```text
.env
.venv
robot_state.json
sandbox_diagnostic_state.json
strategy_profiles.json
trading_events.db
robot_gui.log
robot_debug.log
```

## Проверка

Запустите:

```text
VERIFY_V3_5_3.bat
```

Ожидается:

```text
Version: 0.3.5.3
119 passed
Verification v3.5.3 completed successfully.
```

Затем:

```text
run_gui.bat
```

Заголовок:

```text
MOEX Research Robot v3.5.3
```

## Первая миграция профилей

Если `strategy_profiles.json` отсутствует, программа создаст два профиля из текущих `ROBOT_*` в `.env` или из безопасных defaults:

```text
DRY_RUN
SANDBOX_EXECUTION
```

После запуска:

1. откройте каждый профиль;
2. проверьте PRIMARY, SHADOW, таймфрейм и максимум лотов;
3. сохраните их независимо;
4. перезапустите GUI;
5. повторно проверьте значения.

До этой проверки не разрешайте Sandbox Execution.

## State schema

`robot_state.json` автоматически переводится на schema 5. Старые записи не удаляются. Новые поля добавляются постепенно при работе:

```text
last_periodic_reconcile_at
last_confirmed_current_lots
last_confirmed_target_lots
```

Не очищайте state при открытой позиции.

## Откат

Откат на v3.5.2 допустим только при:

- нулевой позиции;
- отсутствии pending order;
- сохранённой резервной копии state.

`strategy_profiles.json` v3.5.2 не используется; его можно сохранить для возврата к v3.5.3.

## CLI

`run_bot.py` теперь использует `strategy_profiles.json`. Первый DRY_RUN может создать профиль из старых `ROBOT_*`; Sandbox Execution требует заранее сохранённый профиль `SANDBOX_EXECUTION` и не использует скрытый fallback.
