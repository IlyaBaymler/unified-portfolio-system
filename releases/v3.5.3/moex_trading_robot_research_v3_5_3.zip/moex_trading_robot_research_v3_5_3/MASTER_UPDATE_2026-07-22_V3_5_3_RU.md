# Обновление 00 MASTER — 2026-07-22 — v3.5.3

**Решение:** разработать maintenance-релиз v3.5.3 Portfolio State & Configuration Safety.

**Основание:** v3.5.2 прошла естественный Sandbox-цикл BUY → SELL, но журналы выявили случайное переключение PRIMARY/SHADOW, непривязанную позицию после потери ownership, коллизию diagnostic request ID и отсутствие явных событий полного восстановления circuit breaker.

**Выполнено:**

- раздельные атомарные профили DRY_RUN и SANDBOX_EXECUTION;
- checksum и fail-closed конфигурации;
- новая вкладка виртуального портфеля;
- строгий ownership recovery;
- контролируемое закрытие непривязанной позиции;
- периодическая reconciliation;
- явные события circuit breaker;
- уникальные diagnostic IDs;
- state schema 5;
- 119 автоматических тестов и GUI smoke-test.

**Новый статус:** v3.5.3 готова к пользовательскому Sandbox acceptance. Архитектура подготовлена к следующему этапу — Risk Engine и глобальный Portfolio Manager.

**Следующий шаг:** установить hotfix, проверить независимость профилей после рестарта, Portfolio View, `OPEN → HALF_OPEN → CLOSED` без перезапуска и полный Sandbox-цикл с максимумом один лот.

**Главный риск:** системное DNS-разрешение в редком сетевом сценарии может превышать requests connect timeout; этот риск следует отдельно закрыть до автономного сервиса.
