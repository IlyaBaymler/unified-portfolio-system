MOEX Trading Robot v3.5.3 hotfix

Назначение:
- Virtual Portfolio View
- отдельные DRY_RUN/SANDBOX_EXECUTION profiles
- ownership recovery и safe close
- periodic reconciliation
- unique diagnostic IDs
- explicit circuit breaker transitions

Перед установкой остановите робот и сохраните .env, robot_state.json,
sandbox_diagnostic_state.json, strategy_profiles.json и trading_events.db.
Hotfix не должен содержать или заменять runtime-файлы.

После распаковки запустите VERIFY_V3_5_3.bat, затем run_gui.bat.
