# Протокол проверки v3.5 — PRIMARY / SHADOW

## Цель

Доказать, что несколько стратегий корректно работают на новых свечах, но только
PRIMARY влияет на Sandbox-позицию.

## Базовая конфигурация

```text
Тикер: SBER
Class code: TQBR
Интервал: 1 час
PRIMARY: SMA с гистерезисом
SHADOW: Donchian + ATR, ансамбль трендов
SMA: 20 / 50 / 0,2%
Donchian: 55 / 20 / ATR 20 / 3 ATR
Ансамбль: 50 / 200 / momentum 126 / breakout 100 / 3 голоса
Максимум лотов: 1
Volatility targeting: выключен
```

## Этап A. Проверка конфигурации

1. Выполнить `VERIFY_V3_5.bat`.
2. Запустить GUI.
3. Убедиться, что заголовок содержит v3.5.
4. Выбрать PRIMARY и две SHADOW.
5. Сохранить `.env`, перезапустить GUI и проверить восстановление выбора.

Критерий: один PRIMARY, выбранный PRIMARY не может одновременно быть SHADOW.

## Этап B. Одиночный dry-run

1. Нажать «Один цикл — только dry-run».
2. Проверить таблицу решений.
3. Открыть вкладку событий.

Ожидается:

```text
strategy / PRIMARY_DECISION
strategy / SHADOW_DECISION × 2
strategy_comparison / AGREEMENT или DIVERGENCE
cycle / processed
```

Ни одна SHADOW-запись не должна содержать самостоятельное broker order.

## Этап C. Повтор на той же свече

Повторить dry-run до появления новой свечи.

Ожидается:

```text
cycle / already_processed
```

Стратегические решения могут отображаться, но журнал не должен дублировать
одно и то же решение бесконечно.

## Этап D. Сетевая устойчивость

1. Запустить непрерывный dry-run.
2. Кратко отключить сеть.
3. Дождаться `api_degraded`.
4. Восстановить сеть.

Ожидается:

- pending-order отсутствует;
- свеча не исполняется повторно;
- `consecutive_failures` сбрасывается после успешного запроса;
- после трёх полных неудачных циклов circuit breaker переходит OPEN;
- SHADOW не создаёт заявок ни до, ни после восстановления.

## Этап E. Неинтерференция SHADOW

На одной и той же новой свече сравнить:

```text
PRIMARY SMA без SHADOW
PRIMARY SMA + Donchian SHADOW
PRIMARY SMA + Donchian + Ensemble SHADOW
```

Ожидается одинаковый PRIMARY `config_hash`, signal, target_weight и target_lots.
Не исполняйте результаты задним числом: сравнение выполняется в dry-run.

## Этап F. Защита смены стратегии

На нулевой позиции:

1. сменить PRIMARY;
2. выполнить dry-run;
3. проверить `PRIMARY_CHANGED` только в execution mode либо назначение при
   первом реальном preflight.

При открытой Sandbox-позиции попытка сменить PRIMARY или её параметры должна
дать `strategy_switch_blocked`, без новой заявки.

## Этап G. Длительный shadow-run

Длительность: минимум 5–10 торговых сессий, лучше 20+ новых баров для каждого
используемого таймфрейма.

Собирать:

- число новых решений;
- долю AGREEMENT/DIVERGENCE;
- число потенциальных BUY/SELL каждой стратегии;
- изменение target_weight;
- случаи stale data и API degradation;
- отсутствие SHADOW-order;
- стабильность config hash.

## Этап H. Стратегическая Sandbox-заявка

Только после предыдущих этапов:

1. оставить один PRIMARY;
2. максимум один лот;
3. включить Sandbox execution;
4. дождаться естественного нового сигнала;
5. проверить BUY → reconciliation;
6. не менять параметры до естественного SELL;
7. проверить SELL → reconciliation.

## Acceptance criteria

- 0 заявок от SHADOW;
- 0 дублированных заявок;
- 0 незаметных смен PRIMARY;
- одинаковый PRIMARY при добавлении SHADOW;
- position ownership общий для всех таймфреймов инструмента;
- pending-order блокирует другой таймфрейм;
- каждое решение имеет strategy id/version/config hash;
- после рестарта роли и state восстанавливаются;
- минимум один естественный цикл PRIMARY BUY → SELL завершён reconciliation.
