@echo off
setlocal
cd /d "%~dp0"
title MOEX Robot v3.5.2 Tests

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Virtual environment not found.
  echo Run install_and_run_gui.bat first.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -m pip install -r requirements-dev.txt || goto :fail
".venv\Scripts\python.exe" -m compileall -q . || goto :fail
".venv\Scripts\python.exe" -m pytest -q || goto :fail

echo.
echo All tests passed.
pause
exit /b 0

:fail
echo.
echo [ERROR] Tests failed.
pause
exit /b 1
