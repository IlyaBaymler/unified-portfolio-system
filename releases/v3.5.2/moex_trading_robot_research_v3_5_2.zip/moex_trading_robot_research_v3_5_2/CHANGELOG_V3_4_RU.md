# Changelog v3.4 — Stability & Observability

## Цель релиза

Доказать и сделать наблюдаемым исполнительный путь Sandbox до подключения новых
стратегий: решение → намерение → заявка → статус → фактическая позиция →
восстановление после сбоя.

## Добавлено

### Устойчивость

- раздельные connect/read timeout;
- jitter для exponential backoff;
- классификация временных сетевых и HTTP-ошибок;
- persistent circuit breaker `CLOSED / OPEN / HALF_OPEN`;
- безопасные результаты `api_degraded`, `circuit_open`, `state_locked`;
- автоматическая пауза и восстановление после временного отказа;
- проверка максимального возраста сигнала;
- межпроцессная блокировка `robot_state.json`;
- блокировка второго экземпляра desktop GUI.

### Заявки и восстановление

- формальная машина состояний заявки;
- сохранение pending intent перед отправкой;
- переходы `ORDER_SUBMITTED`, `ORDER_ACCEPTED`, `FILLED`,
  `PARTIALLY_FILLED`, `REJECTED`, `CANCELLED`;
- `SUBMISSION_FAILED` для конкретного не-временного HTTP-отказа;
- восстановление потерянного ответа по тому же idempotency key;
- один цикл не выполняет сразу recovery и новое торговое решение;
- повторная сверка ожидаемой и фактической позиции;
- блокировка новых поручений при `RECONCILIATION_REQUIRED`;
- безопасный отказ запуска при повреждённом state-файле.

### Диагностика

- новая вкладка «Диагностика заявок»;
- независимый от стратегии тест ровно одного лота;
- проверка торгового статуса, доступного количества и активных поручений;
- контролируемые BUY/SELL;
- отдельный state-файл;
- ручное recovery незавершённой операции.

### Наблюдаемость

- `trading_events.db` в SQLite WAL;
- категории cycle, order, incident, diagnostic, diagnostic_order;
- просмотр событий из GUI;
- фильтрация и экспорт CSV;
- панель API/data age/mode/signal/position/pending/failures/next retry;
- технический журнал остаётся в `robot_gui.log`.

### Конфигурация

Новые переменные `.env`:

```text
TBANK_CONNECT_TIMEOUT_SECONDS
TBANK_READ_TIMEOUT_SECONDS
ROBOT_JOURNAL_FILE
ROBOT_FAILURE_THRESHOLD
ROBOT_CIRCUIT_OPEN_SECONDS
ROBOT_CIRCUIT_MAX_OPEN_SECONDS
ROBOT_MAX_SIGNAL_AGE_SECONDS
ROBOT_RECONCILE_ATTEMPTS
ROBOT_RECONCILE_DELAY_SECONDS
```

## Исправлено

- не-временной отказ `PostSandboxOrder` больше не остаётся в бесконечном цикле
  автоматического resubmit;
- потерянный сетевой ответ после отправки не приводит к новой заявке с другим ID;
- GUI валидирует тайм-ауты до сохранения `.env`;
- горизонтальная полоса журнала событий больше не перекрывает таблицу;
- события обновляются после фоновой ошибки;
- diagnostic ticker/class синхронизируются с загруженными Sandbox-настройками.

## Автоматические проверки

- 48 тестов;
- компиляция всех Python-файлов;
- smoke-test создания desktop GUI под виртуальным дисплеем;
- сценарии timeout, circuit breaker, partial fill, reconciliation mismatch,
  потерянного ответа, non-transient rejection и повреждённого state-файла.

## Не входит в v3.4

- реальные счета;
- автоматическая торговля Donchian/ensemble;
- многоинструментный портфель;
- отмена/замена долгоживущих DAY-заявок;
- полноценный portfolio kill switch;
- моделирование реальной очереди и стакана.
