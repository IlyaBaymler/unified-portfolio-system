# Обновление v3.5.1 → v3.5.2

## Перед обновлением

1. Остановите DRY-RUN и Sandbox Execution.
2. Закройте GUI.
3. Убедитесь, что нет незавершённого `pending_order`.
4. Создайте резервные копии:

```text
.env
robot_state.json
sandbox_diagnostic_state.json
trading_events.db
```

Не удаляйте state-файлы: они содержат защиту от повторных заявок.

## Установка

1. Распакуйте содержимое `moex_trading_robot_v3_5_2_state_hotfix.zip`
   непосредственно в папку установленной v3.5.1.
2. Подтвердите замену файлов.
3. Проверьте, что не появилась лишняя вложенная папка.
4. Запустите:

```text
VERIFY_V3_5_2.bat
```

5. Затем запустите:

```text
run_gui.bat
```

Заголовок должен содержать:

```text
MOEX Research Robot v3.5.2
```

## Hotfix не заменяет

```text
.env
.venv
robot_state.json
sandbox_diagnostic_state.json
trading_events.db
robot_gui.log
robot_debug.log
```

## Первый тест

Используйте неизменную конфигурацию:

```text
SBER / TQBR
1 час
PRIMARY: SMA 20/50, гистерезис 0,2%
SHADOW: Donchian + ATR, Ensemble
максимум: 1 лот
режим: DRY-RUN
```

Ожидаемые обозначения:

```text
WOULD_BUY  — заявка не отправлялась
WOULD_SELL — заявка не отправлялась
HOLD       — фактическая позиция уже соответствует цели
```

Во вкладке событий при кратковременной блокировке state-файла должны появиться:

```text
STATE_SAVE_RETRY
STATE_SAVE_RECOVERED
```

При окончательном отказе:

```text
state_save_failed
STATE_SAVE_FAILED
```

В этом состоянии не запускайте новую заявку до успешного следующего цикла и
проверки `pending_order`.
