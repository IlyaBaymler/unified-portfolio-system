from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
import errno
import json
import os
from pathlib import Path
import random
import time
from typing import Any
from uuid import uuid4


StateEventCallback = Callable[[str, dict[str, Any]], None]


DEFAULT_RETRY_DELAYS: tuple[float, ...] = (
    0.05,
    0.10,
    0.20,
    0.40,
    0.80,
    1.60,
    3.20,
)

_TRANSIENT_ERRNOS = {
    errno.EACCES,
    errno.EBUSY,
    errno.EPERM,
}
_TRANSIENT_WINERRORS = {
    5,   # ERROR_ACCESS_DENIED
    32,  # ERROR_SHARING_VIOLATION
    33,  # ERROR_LOCK_VIOLATION
}


@dataclass(frozen=True, slots=True)
class StateSaveResult:
    path: str
    attempt_count: int
    retry_count: int
    duration_seconds: float


class StatePersistenceError(RuntimeError):
    """Raised when a local state file cannot be durably replaced.

    A failure is treated as safety-critical because the state file carries
    pending-order and idempotency information.  Callers must stop the current
    trading action and reconcile on a later cycle rather than continuing with
    an uncertain local state.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        phase: str,
        attempts: int,
        last_error: BaseException,
    ) -> None:
        self.path = Path(path)
        self.phase = str(phase)
        self.attempts = int(attempts)
        self.last_error = last_error
        super().__init__(
            "Не удалось надёжно сохранить локальное состояние "
            f"{self.path} (этап: {self.phase}, попыток: {self.attempts}): "
            f"{last_error}"
        )


def atomic_write_json(
    path: str | Path,
    state: Mapping[str, Any],
    *,
    retry_delays: Sequence[float] = DEFAULT_RETRY_DELAYS,
    jitter_fraction: float = 0.15,
    event_callback: StateEventCallback | None = None,
) -> StateSaveResult:
    """Durably and atomically replace a JSON state file.

    The temporary file is unique and resides in the destination directory so
    ``os.replace`` stays atomic.  On Windows, antivirus/indexing/cloud-sync
    software can briefly hold the destination file open; transient sharing or
    access errors are retried with exponential delays and jitter.
    """

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    payload = json.dumps(
        state,
        ensure_ascii=False,
        indent=2,
        default=str,
    )
    temporary = destination.with_name(
        f"{destination.name}.{os.getpid()}.{uuid4().hex}.tmp"
    )

    try:
        try:
            with temporary.open(
                "x",
                encoding="utf-8",
                newline="\n",
            ) as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
        except Exception as exc:
            details = _event_payload(
                destination=destination,
                temporary=temporary,
                phase="write_temp",
                attempt=1,
                max_attempts=1,
                error=exc,
                delay_seconds=0.0,
            )
            _emit(event_callback, "STATE_SAVE_FAILED", details)
            raise StatePersistenceError(
                destination,
                phase="write_temp",
                attempts=1,
                last_error=exc,
            ) from exc

        delays = tuple(max(0.0, float(delay)) for delay in retry_delays)
        max_attempts = len(delays) + 1
        last_error: BaseException | None = None

        for attempt in range(1, max_attempts + 1):
            try:
                os.replace(temporary, destination)
                _sync_parent_directory_best_effort(destination.parent)
                duration = max(0.0, time.perf_counter() - started)
                if attempt > 1:
                    _emit(
                        event_callback,
                        "STATE_SAVE_RECOVERED",
                        {
                            "path": str(destination),
                            "attempt_count": attempt,
                            "retry_count": attempt - 1,
                            "duration_seconds": round(duration, 6),
                        },
                    )
                return StateSaveResult(
                    path=str(destination),
                    attempt_count=attempt,
                    retry_count=attempt - 1,
                    duration_seconds=duration,
                )
            except OSError as exc:
                last_error = exc
                if not _is_transient_replace_error(exc) or attempt >= max_attempts:
                    break

                base_delay = delays[attempt - 1]
                jitter = (
                    random.uniform(0.0, base_delay * jitter_fraction)
                    if base_delay > 0 and jitter_fraction > 0
                    else 0.0
                )
                delay = base_delay + jitter
                _emit(
                    event_callback,
                    "STATE_SAVE_RETRY",
                    _event_payload(
                        destination=destination,
                        temporary=temporary,
                        phase="replace",
                        attempt=attempt,
                        max_attempts=max_attempts,
                        error=exc,
                        delay_seconds=delay,
                    ),
                )
                time.sleep(delay)

        assert last_error is not None
        duration = max(0.0, time.perf_counter() - started)
        attempts_used = attempt
        details = _event_payload(
            destination=destination,
            temporary=temporary,
            phase="replace",
            attempt=attempts_used,
            max_attempts=max_attempts,
            error=last_error,
            delay_seconds=0.0,
        )
        details["duration_seconds"] = round(duration, 6)
        _emit(event_callback, "STATE_SAVE_FAILED", details)
        raise StatePersistenceError(
            destination,
            phase="replace",
            attempts=attempts_used,
            last_error=last_error,
        ) from last_error
    finally:
        # After a successful replace the temporary path no longer exists.
        # After a failed replace it is safe to remove because no order action
        # is allowed to continue from the caller.
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def _is_transient_replace_error(exc: OSError) -> bool:
    if isinstance(exc, PermissionError):
        return True
    if getattr(exc, "winerror", None) in _TRANSIENT_WINERRORS:
        return True
    return getattr(exc, "errno", None) in _TRANSIENT_ERRNOS


def _event_payload(
    *,
    destination: Path,
    temporary: Path,
    phase: str,
    attempt: int,
    max_attempts: int,
    error: BaseException,
    delay_seconds: float,
) -> dict[str, Any]:
    return {
        "path": str(destination),
        "temporary_path": str(temporary),
        "phase": phase,
        "attempt": int(attempt),
        "max_attempts": int(max_attempts),
        "delay_seconds": round(float(delay_seconds), 6),
        "error_type": type(error).__name__,
        "error": str(error),
        "errno": getattr(error, "errno", None),
        "winerror": getattr(error, "winerror", None),
    }


def _emit(
    callback: StateEventCallback | None,
    event_type: str,
    payload: dict[str, Any],
) -> None:
    if callback is None:
        return
    try:
        callback(event_type, dict(payload))
    except Exception:
        # State persistence must not depend on logging availability.
        pass


def _sync_parent_directory_best_effort(directory: Path) -> None:
    if os.name == "nt":
        return
    flags = getattr(os, "O_DIRECTORY", 0) | os.O_RDONLY
    try:
        descriptor = os.open(directory, flags)
    except OSError:
        return
    try:
        os.fsync(descriptor)
    except OSError:
        pass
    finally:
        os.close(descriptor)
