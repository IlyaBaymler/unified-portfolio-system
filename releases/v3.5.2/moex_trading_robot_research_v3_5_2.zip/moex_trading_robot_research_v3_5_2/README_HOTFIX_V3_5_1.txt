MOEX Trading Robot v3.5.1 — Observability Hotfix

Распакуйте содержимое архива поверх установленной v3.5.
Файлы .env, robot_state.json, trading_events.db и журналы не включены.
После замены запустите VERIFY_V3_5_1.bat, затем run_gui.bat.
Подробности: UPDATE_TO_V3_5_1.md и CHANGELOG_V3_5_1_RU.md.
