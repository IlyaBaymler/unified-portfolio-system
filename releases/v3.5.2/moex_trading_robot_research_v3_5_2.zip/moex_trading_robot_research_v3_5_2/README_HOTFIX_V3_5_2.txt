MOEX Trading Robot v3.5.2 — State Persistence Hotfix

Распакуйте содержимое архива поверх установленной v3.5.1.
Файлы .env, .venv, robot_state.json, trading_events.db и журналы не включены.
После замены запустите VERIFY_V3_5_2.bat, затем run_gui.bat.
Подробности: UPDATE_TO_V3_5_2.md и CHANGELOG_V3_5_2_RU.md.
