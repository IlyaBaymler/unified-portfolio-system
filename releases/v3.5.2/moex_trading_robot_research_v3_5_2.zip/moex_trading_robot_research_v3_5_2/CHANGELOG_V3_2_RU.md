# Changelog v3.2

- Исправлен адрес Sandbox: теперь используется официальный выделенный хост
  `sandbox-invest-public-api.tbank.ru`.
- Добавлена работа через системное хранилище сертификатов Windows (`truststore`).
- Добавлена поддержка пользовательского PEM CA bundle.
- Добавлена понятная диагностика ошибок НУЦ Минцифры / HTTPS inspection.
- Проверка TLS не отключается ни в одном режиме.
- Добавлены `diagnose_tbank_tls.bat` и `update_tls_dependencies.bat`.
- Версия GUI изменена на v3.2.
