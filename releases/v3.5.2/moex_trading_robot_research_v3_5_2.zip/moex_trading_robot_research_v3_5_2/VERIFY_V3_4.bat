@echo off
setlocal
cd /d "%~dp0"
title Verify MOEX Robot v3.4

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Virtual environment not found.
  echo Run install_and_run_gui.bat first.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -c "import trading_robot; print('Version:', trading_robot.__version__)" || goto :fail
".venv\Scripts\python.exe" -m compileall -q . || goto :fail
".venv\Scripts\python.exe" -c "from trading_robot.bot import SandboxTradingBot; from trading_robot.diagnostics import SandboxOrderDiagnostics; from trading_robot.journal import EventJournal; print('v3.4 modules: OK')" || goto :fail

echo.
echo Verification completed successfully.
pause
exit /b 0

:fail
echo.
echo [ERROR] Verification failed.
pause
exit /b 1
