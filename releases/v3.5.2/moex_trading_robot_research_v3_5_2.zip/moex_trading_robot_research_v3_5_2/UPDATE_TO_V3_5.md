# Обновление MOEX Trading Robot v3.4.1 → v3.5

## 1. Подготовка

1. Остановите непрерывный робот.
2. Закройте GUI.
3. Убедитесь, что во вкладке диагностики нет неизвестного pending-order.
4. Скопируйте в безопасное место:

```text
.env
robot_state.json
sandbox_diagnostic_state.json
trading_events.db
robot_gui.log
```

## 2. Установка hotfix

Распакуйте содержимое архива `moex_trading_robot_v3_5_strategy_hotfix.zip`
непосредственно в существующую папку v3.4.1 и согласитесь на замену файлов.

Не создавайте дополнительную вложенную папку.

Hotfix не содержит и не заменяет:

```text
.env
.venv
robot_state.json
sandbox_diagnostic_state.json
trading_events.db
robot_gui.log
```

## 3. Проверка

Запустите:

```text
VERIFY_V3_5.bat
```

Затем:

```text
run_gui.bat
```

В заголовке должно быть:

```text
MOEX Research Robot v3.5
```

## 4. Миграция состояния

- старый SMA-state переносится в versioned state-key v3.5;
- свеча, уже использованная v3.4.1, не исполняется повторно;
- при нулевой позиции v3.5 назначает владельца PRIMARY автоматически;
- при открытой позиции без ownership-записи исполнение блокируется: сначала
  закройте или вручную сверяйте позицию;
- ownership разных таймфреймов объединяется на уровне счёт + инструмент.

Не удаляйте state-файл для обхода блокировки: сначала установите фактическое
состояние заявок и позиции у брокера.

## 5. Новые параметры `.env`

Можно добавить:

```text
ROBOT_PRIMARY_STRATEGY=sma
ROBOT_SHADOW_STRATEGIES=donchian,ensemble
ROBOT_SMA_HYSTERESIS_PERCENT=0.2
ROBOT_DONCHIAN_ENTRY_WINDOW=55
ROBOT_DONCHIAN_EXIT_WINDOW=20
ROBOT_DONCHIAN_ATR_WINDOW=20
ROBOT_DONCHIAN_TRAILING_STOP_ATR=3.0
ROBOT_ENSEMBLE_SMA_FAST=50
ROBOT_ENSEMBLE_SMA_SLOW=200
ROBOT_ENSEMBLE_MOMENTUM_WINDOW=126
ROBOT_ENSEMBLE_BREAKOUT_WINDOW=100
ROBOT_ENSEMBLE_VOTE_THRESHOLD=3
ROBOT_TARGET_VOLATILITY_PERCENT=
ROBOT_VOLATILITY_WINDOW=20
ROBOT_MAX_STRATEGY_WEIGHT_PERCENT=100
```

Без этих строк обновлённая программа всё равно запустится с безопасными
значениями по умолчанию.

## 6. Первый запуск

1. PRIMARY: SMA с гистерезисом.
2. SHADOW: Donchian + ATR и ансамбль.
3. Интервал: один час.
4. Максимум: один лот.
5. Выполнить один dry-run.
6. Проверить таблицу PRIMARY/SHADOW.
7. Запустить непрерывный dry-run на 5–10 сессий.
8. Не включать стратегическое исполнение до проверки журнала расхождений.
