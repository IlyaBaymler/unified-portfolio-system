# Протокол проверки v3.5.2

## A. Smoke-test

1. `VERIFY_V3_5_2.bat` — все тесты должны пройти.
2. Запустить один dry-run.
3. Проверить версию `v3.5.2` и отсутствие traceback.

## B. Ясность dry-run

При сигнале входа ожидается:

```text
action = WOULD_BUY
intended_action = BUY
order_was_sent = false
```

При сигнале выхода ожидается `WOULD_SELL`.

## C. Длительный state-test

1. Запустить часовой PRIMARY/SHADOW dry-run на 2–3 часа.
2. Не открывать `robot_state.json` редактором во время работы.
3. Проверить отсутствие необработанного `WinError 5`.
4. Если Windows временно блокирует файл, ожидаются
   `STATE_SAVE_RETRY → STATE_SAVE_RECOVERED`.

## D. Circuit breaker

1. Отключить сеть и оставить её отключённой до трёх отдельных циклов
   `api_degraded`.
2. Проверить `CLOSED → OPEN`.
3. Восстановить сеть после времени следующей попытки.
4. Проверить `HALF_OPEN → CLOSED`.
5. Убедиться, что `pending_order` не появился.

## E. Sandbox gate

После A–D разрешить PRIMARY Sandbox Execution только с одним лотом и на новой,
не просмотренной в dry-run свече. Проверить:

```text
INTENT_SAVED
ORDER_SUBMITTED
ORDER_ACCEPTED/FILLED
PORTFOLIO_RECONCILED
order_was_sent = true
```

Критерий провала: дублированная заявка, потерянный pending-order, постоянный
`state_save_failed` или расхождение позиции.
