# Changelog v3.5.1 — Observability & Logging

Дата: 20.07.2026  
Приложение: MOEX Trading Robot v3.5.1  
Пакет Python: 0.3.5.1  
Формат SQLite-журнала: schema v2, миграция без удаления старых событий

## Назначение релиза

v3.5.1 не меняет формулы стратегий, правила PRIMARY/SHADOW, размер позиции или
логику отправки заявок. Релиз улучшает наблюдаемость длительного forward-run и
устраняет чрезмерно подробные INFO-записи, замеченные в двухчасовом тесте v3.5.

## Изменения

### Два технических журнала

- `robot_gui.log` — компактный операторский журнал с ротацией 5 × 5 МБ;
- `robot_debug.log` — подробные DEBUG-пayload с ротацией 3 × 10 МБ;
- токены и заголовки Bearer редактируются перед выводом в GUI и на диск;
- полные словари цикла перенесены с INFO на DEBUG.

### Компактные сообщения цикла

INFO теперь содержит одну строку с:

```text
session / run / mode / ticker / status / candle / signal /
action / current→target lots / duration / retries
```

`already_processed` выводится в INFO как heartbeat не чаще одного раза за
`ROBOT_HEARTBEAT_LOG_SECONDS`; остальные повторы остаются только в DEBUG.

### Структурированный журнал schema v2

Добавлены индексируемые колонки:

```text
session_id, mode, status, action, strategy_id, config_hash,
duration_seconds, api_attempts
```

Существующая база `trading_events.db` мигрируется на месте. Старые строки не
удаляются.

### Разделение решения и заявки

Событие без брокерского поручения теперь записывается как:

```text
decision / TRADE_DECISION
```

Категория `order` начинается только с сохранённого intent и реального жизненного
цикла заявки. Это устраняет вводящую в заблуждение запись
`order / DECISION_CREATED` для действия `HOLD`.

### Сессии робота

Каждый одиночный или непрерывный запуск получает `session_id` и события:

```text
session / STARTED
session / STOPPED
```

Сохраняются режим, стратегия, config hash, длительность и причина остановки.

### API telemetry

Явно записываются:

```text
api / API_RETRY_SCHEDULED
api / API_RETRY_RECOVERED
api / API_REQUEST_FAILED
api / API_SLOW_REQUEST
```

Для запроса сохраняются сервис, метод, число попыток, задержки, длительность,
HTTP-код и tracking ID. Payload и токен запроса не журналируются.

### Производительность цикла

Результат цикла содержит:

```text
cycle_started_at
cycle_finished_at
cycle_duration_seconds
api_completed_at
api_last_duration_seconds
api_last_attempt_count
api_retry_count
timings: instrument_resolution, candle_load, strategy_evaluation,
         portfolio_read, trading_status, max_lots,
         order_submission, order_state_read, position_reconciliation
```

Цикл дольше `ROBOT_SLOW_CYCLE_SECONDS` создаёт событие
`performance / SLOW_CYCLE`.

### GUI журнала

Во вкладке «События v3.5.1» добавлены:

- фильтр по категории;
- фильтр по severity;
- фильтр по session ID;
- полнотекстовый поиск;
- колонки режима, действия, длительности и сессии;
- подсветка WARNING/ERROR;
- счётчики всех событий, предупреждений и ошибок;
- экспорт текущего отфильтрованного набора в CSV.

## Совместимость

Не изменены:

- `robot_state.json` и его version 4;
- детерминированный `orderId`;
- формулы SMA, Donchian и ансамбля;
- config hash стратегий;
- PRIMARY/SHADOW и защита владельца позиции;
- Sandbox-only endpoint.

## Проверка

```text
Python compileall: успешно
78 unit/integration tests: успешно
GUI smoke-test: успешно
миграция SQLite v1 → v2: успешно
retry → recovery telemetry: успешно
решение HOLD не попадает в category=order: успешно
редактирование токена в логах: успешно
метаданные старого API-вызова не переносятся в цикл без обращения к API: успешно
```
