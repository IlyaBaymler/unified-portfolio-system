@echo off
setlocal
cd /d "%~dp0"
title Verify MOEX Robot v3.4.1

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Virtual environment not found.
  echo Run install_and_run_gui.bat first.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -c "import trading_robot; assert trading_robot.__version__ == '0.3.4.1'; print('Version:', trading_robot.__version__)" || goto :fail
".venv\Scripts\python.exe" -m compileall -q . || goto :fail
".venv\Scripts\python.exe" -c "from trading_robot.gui_clipboard import resolve_clipboard_action; assert resolve_clipboard_action(keysym='Cyrillic_em', keycode=86, state=4) == 'paste'; print('Clipboard shortcuts: OK')" || goto :fail

if exist "requirements-dev.txt" (
  ".venv\Scripts\python.exe" -m pytest -q || goto :fail
)

echo.
echo Verification completed successfully.
pause
exit /b 0

:fail
echo.
echo [ERROR] Verification failed.
pause
exit /b 1
