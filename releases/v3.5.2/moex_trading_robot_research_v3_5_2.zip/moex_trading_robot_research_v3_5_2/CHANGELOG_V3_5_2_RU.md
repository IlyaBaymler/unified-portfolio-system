# Changelog v3.5.2 — State Persistence & Dry-run Clarity

Дата: 21.07.2026  
Тип релиза: safety/maintenance hotfix поверх v3.5.1

## Исправленные ошибки

### 1. `WinError 5` при сохранении `robot_state.json`

В v3.5.1 использовалось фиксированное имя `robot_state.json.tmp` и один вызов
`os.replace`. Кратковременная блокировка файла Windows, антивирусом,
индексатором или облачной синхронизацией завершала торговый цикл исключением.

В v3.5.2:

- временный файл получает уникальное имя `state.<pid>.<uuid>.tmp`;
- данные записываются через `flush` и `fsync`;
- атомарная замена повторяется при `PermissionError`, sharing violation и lock
  violation;
- задержки растут от 50 мс до 3,2 с и содержат небольшой jitter;
- прежний валидный state-файл сохраняется, если замена окончательно не удалась;
- оставшийся временный файл удаляется;
- тот же механизм применяется к `sandbox_diagnostic_state.json`.

### 2. Безопасное завершение при окончательном отказе записи

При исчерпании повторов робот возвращает:

```text
status = state_save_failed
new_orders_blocked = true
api_state = LOCAL_STATE_ERROR
```

Новая заявка в этом цикле не создаётся. Если запрос брокеру уже мог быть
отправлен, результат содержит `order_may_have_been_sent = true`; следующий цикл
восстанавливает операцию по ранее сохранённому детерминированному `orderId`.

### 3. Неоднозначная надпись `BUY` в dry-run

В режиме без исполнения теперь отображается:

```text
WOULD_BUY
WOULD_SELL
```

Дополнительные поля:

```text
intended_action = BUY/SELL/HOLD
order_was_sent = true/false
```

### 4. Старое решение в payload сетевой ошибки

При `api_degraded` текущие поля `strategy_decisions` и
`strategy_comparison` теперь пусты. Последнее успешное решение находится в:

```text
last_known_strategy_decisions
last_known_strategy_comparison
```

Это исключает интерпретацию старого сигнала как рассчитанного в неудачном
сетевом цикле.

### 5. Дедупликация решений между сессиями

Одно решение по-прежнему записывается не более одного раза внутри сессии, но
новый запуск получает собственную строку `PRIMARY_DECISION`/`SHADOW_DECISION`.
Поэтому анализ по `session_id` больше не теряет первую свечу новой сессии.

## Новые структурированные события

```text
state / STATE_SAVE_RETRY
state / STATE_SAVE_RECOVERED
state / STATE_SAVE_FAILED
```

Вкладка «События v3.5.2» получила категорию `state`.

## Что не менялось

- формулы SMA, Donchian, ATR и ансамбля;
- значения `config_hash` стратегий;
- PRIMARY/SHADOW-изоляция;
- модель целевых лотов;
- логика `orderId`, pending-order и reconciliation;
- формат `robot_state.json` версии 4;
- SQLite schema v2;
- Sandbox-only endpoint.

## Известные ограничения

- постоянный запрет записи в папку не может быть автоматически устранён;
  робот безопасно остановит торговое действие со статусом `state_save_failed`;
- рабочую папку по-прежнему предпочтительно размещать вне OneDrive, а резервную
  копию синхронизировать после остановки робота;
- `WOULD_BUY` в последовательных dry-run-свечах означает повторяемое намерение,
  а не дублированную заявку: фактическая Sandbox-позиция остаётся нулевой.

## Проверка релиза

```text
Python compileall: passed
89 unit/integration tests: passed
GUI smoke-test: passed
state retry/recovery: passed
state failure preserves previous file: passed
post-submit save failure recovery without duplicate: passed
```

## Минимальный сценарий

1. Установить hotfix поверх v3.5.1.
2. Запустить `VERIFY_V3_5_2.bat`.
3. Выполнить часовой dry-run до новой свечи.
4. Убедиться, что намерение отображается как `WOULD_BUY`/`WOULD_SELL`.
5. Выполнить тест трёх отдельных сетевых отказов для circuit breaker.
6. Только после успешной проверки разрешать Sandbox Execution на один лот.
