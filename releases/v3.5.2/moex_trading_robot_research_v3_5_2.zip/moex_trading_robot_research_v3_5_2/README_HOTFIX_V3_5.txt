MOEX Trading Robot v3.5 Strategy Hotfix

1. Stop the robot and close the GUI.
2. Back up .env, robot_state.json, sandbox_diagnostic_state.json and trading_events.db.
3. Extract this archive directly into the installed v3.4.1 project folder.
4. Confirm file replacement.
5. Run VERIFY_V3_5.bat.
6. Run run_gui.bat and confirm the title "MOEX Research Robot v3.5".

The hotfix does not contain .env, .venv, state files, databases or logs.
Read UPDATE_TO_V3_5.md before enabling Sandbox execution.
