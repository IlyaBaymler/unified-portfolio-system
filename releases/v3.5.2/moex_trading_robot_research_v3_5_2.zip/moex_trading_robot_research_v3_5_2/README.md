# MOEX Trading Robot — Research Edition v3.5.2


Версия **v3.5.2 State Persistence & Dry-run Clarity** — safety-hotfix поверх
v3.5.1. Она устраняет кратковременный `WinError 5` при замене
`robot_state.json`, добавляет повторную атомарную запись через уникальный
временный файл, `fsync`, структурированные события состояния и безопасный
статус `state_save_failed`. В dry-run действия теперь называются
`WOULD_BUY`/`WOULD_SELL`, чтобы их нельзя было спутать с отправленной заявкой.

Версия **v3.5.1 Observability & Logging** — технический релиз поверх v3.5.
Формулы стратегий и исполнительная логика не менялись. Добавлены компактный и
подробный журналы, session ID, API retry telemetry, длительности фаз цикла,
разделение `decision` и `order`, а также расширенные фильтры SQLite-журнала.


Версия **v3.5 Unified Strategy Interface & Shadow Mode** подключает к уже
проверенному исполнительному контуру T-Invest Sandbox три стратегии из общего
научного ядра:

- SMA с гистерезисом;
- Donchian breakout + ATR trailing exit;
- ансамбль медленных трендовых сигналов.

Одна стратегия назначается **PRIMARY**. Только она может создать виртуальную
заявку. Остальные стратегии работают в режиме **SHADOW**: получают те же новые
завершённые свечи, рассчитывают решение, сохраняют параметры и объяснение в
SQLite-журнале, но не имеют пути к брокерской заявке.

Проект работает только с **T-Invest Sandbox**. Production-метода выставления
заявок на реальном счёте в коде нет.


## Главное в v3.5.2

### Надёжная запись состояния

```text
уникальный state.<pid>.<uuid>.tmp
→ flush + fsync
→ os.replace с повторными попытками
→ STATE_SAVE_RECOVERED или безопасный STATE_SAVE_FAILED
```

Кратковременные блокировки Windows, антивируса или облачной синхронизации
повторяются с растущей задержкой. Если все попытки исчерпаны, текущий цикл
завершается без новой заявки. Если поручение уже могло быть принято, сохранённый
до отправки `pending_order` используется для восстановления по тому же
детерминированному `orderId`.

Структурированные события:

```text
state / STATE_SAVE_RETRY
state / STATE_SAVE_RECOVERED
state / STATE_SAVE_FAILED
```

### Ясность dry-run

```text
WOULD_BUY  — робот купил бы, но поручение не отправлялось
WOULD_SELL — робот продал бы, но поручение не отправлялось
BUY/SELL   — режим исполнения; проверяйте order_was_sent
```

При сетевой деградации старые сигналы теперь помещаются в поля
`last_known_strategy_decisions`, а поля текущего цикла остаются пустыми.
Решения одной свечи также журналируются отдельно для каждой новой сессии.

## Главное в v3.5.1

### Улучшенное протоколирование

```text
robot_gui.log    компактный операторский журнал
robot_debug.log  полный DEBUG-журнал с payload
trading_events.db schema v2: session/cycle/decision/api/order/performance
```

Повторные `already_processed` не засоряют INFO: heartbeat выводится по
настраиваемому интервалу. Решение `HOLD` записывается как
`decision/TRADE_DECISION`, а категория `order` используется только для
фактического жизненного цикла заявки.

## Функции v3.5

### Единый контракт стратегии

Каждая стратегия возвращает версионированный объект решения:

```text
StrategyDecision
  candle_time
  strategy_id / strategy_version
  role = PRIMARY или SHADOW
  config_hash
  signal
  target_weight
  target_lots
  reason
  indicators
  stop_level
  bars_used / required_bars
```

Стратегия отвечает только за желаемую позицию. Слой исполнения по-прежнему
отдельно выполняет:

```text
фактическая позиция
→ разница с целью PRIMARY
→ preflight
→ pending intent
→ Sandbox-заявка
→ статус
→ portfolio reconciliation
```

### Shadow mode

На каждой новой завершённой свече:

1. загружается единый набор рыночных данных;
2. PRIMARY и выбранные SHADOW-стратегии рассчитываются независимо;
3. решения сохраняются в категориях `strategy` и `strategy_comparison`;
4. при расхождении создаётся событие `DIVERGENCE`;
5. заявка может быть сформирована только из решения PRIMARY.

Добавление SHADOW не меняет окно реконструкции PRIMARY: каждая стратегия
использует стабильное собственное live-окно. Это исключает ситуацию, когда
простое включение наблюдаемой стратегии меняет исполняемый сигнал из-за иной
длины загруженной истории.

### Защита конфигурации и позиции

- параметры стратегии блокируются в GUI на время работы цикла;
- конфигурация идентифицируется SHA-256 `config_hash`;
- `orderId` включает PRIMARY и её `config_hash`;
- смена PRIMARY или её параметров при открытой позиции блокируется;
- позиция без подтверждённого владельца v3.5 считается неатрибутированной;
- pending-order другой конфигурации блокирует новое исполнение;
- владение позицией задаётся на уровне **счёт + инструмент**, а не таймфрейм:
  часовой и дневной роботы не могут независимо управлять одной позицией.

### Стратегии

#### SMA с гистерезисом

```text
fast > slow × (1 + h) → вход
fast < slow × (1 − h) → выход
между границами        → сохранить состояние
```

Гистерезис уменьшает частые переключения около пересечения средних.

#### Donchian + ATR

```text
close выше предыдущего верхнего канала → вход
close ниже нижнего канала              → выход
close ниже ATR trailing stop           → выход
```

Стоп в текущей версии проверяется по завершённой свече, а не как внутрисвечная
биржевая стоп-заявка.

#### Ансамбль трендов

Голоса:

1. быстрая SMA выше медленной;
2. цена выше медленной EMA;
3. momentum положителен;
4. цена выше предыдущего breakout-уровня.

При достижении заданного числа голосов стратегия переходит в LONG.

### Размер позиции

Без volatility targeting:

```text
signal = 1 → target_lots = ROBOT_MAX_ORDER_LOTS
signal = 0 → target_lots = 0
```

При включённой целевой волатильности `target_weight` масштабирует максимальное
число лотов. Это ограниченный одноинструментный механизм, а не полный
портфельный risk engine; он запланирован для v3.6.

## Сохранённые возможности v3.4.1

- раздельные connect/read timeout;
- exponential backoff с jitter;
- persistent circuit breaker;
- stale-signal guard;
- детерминированный `orderId`;
- pending intent до сетевой отправки;
- восстановление потерянного ответа;
- обработка partial fill;
- portfolio reconciliation;
- межпроцессная блокировка state-файла;
- отдельная вкладка контролируемых заявок по одному лоту;
- системное TLS-хранилище Windows;
- Ctrl+V токена при русской и английской раскладке;
- SQLite audit trail и экспорт CSV.

## Установка в Windows

### Чистая установка

1. Распакуйте архив в обычную папку, например `C:\MOEX_Robot_v3_5`.
2. Запустите:

```text
install_and_run_gui.bat
```

3. После первой установки используйте:

```text
run_gui.bat
```

### Обновление v3.4.1

Для обновления с v3.5.1 смотрите `UPDATE_TO_V3_5_2.md`. Перед обновлением остановите робот и сохраните
копии:

```text
.env
robot_state.json
sandbox_diagnostic_state.json
trading_events.db
```

## Первый безопасный запуск v3.5.2

Рекомендуемая конфигурация:

```text
Инструмент:       SBER / TQBR
Интервал:         1 час
PRIMARY:          SMA с гистерезисом
SHADOW:           Donchian + ATR, ансамбль трендов
Максимум лотов:   1
Целевая волатильность: выключена
Режим:            непрерывный dry-run
```

Проверьте 5–10 торговых сессий до разрешения стратегии отправлять виртуальные
заявки. Подробный протокол: `V3_5_SHADOW_TEST_PLAN_RU.md`.

## Консольный запуск

Создайте `.env`:

```powershell
Copy-Item .env.example .env
```

Dry-run одного цикла:

```powershell
python run_bot.py --once
```

Непрерывный dry-run:

```powershell
python run_bot.py
```

Для виртуального исполнения нужны оба предохранителя:

```text
ARM_SANDBOX_TRADING=YES
```

```powershell
python run_bot.py --once --execute
```

## Входные данные

### Sandbox-контур

- завершённые свечи T-Invest;
- интервалы: 10 минут, 1 час, 1 день;
- поля: `open`, `high`, `low`, `close`, `volume`, `is_complete`;
- фактическая позиция и состояния заявок T-Invest Sandbox.

### Research Lab

- исторические свечи MOEX ISS;
- OHLCV с временным индексом;
- параметры стратегии, издержек и бэктеста.

## Выходные данные

```text
robot_state.json               состояние циклов и pending-order
sandbox_diagnostic_state.json  отдельное состояние диагностики
trading_events.db              SQLite-журнал решений, заявок и инцидентов
robot_gui.log                  компактный операторский журнал
robot_debug.log                подробный DEBUG-журнал
CSV                            экспорт событий и сделок
PNG                            экспорт графиков Research Lab
```

Категории журнала v3.5.2:

```text
session
cycle
decision
api
performance
order
strategy
strategy_comparison
strategy_config
state
```

## Минимальный тестовый сценарий

1. Запустить `VERIFY_V3_5_2.bat`.
2. Проверить подключение к Sandbox.
3. Выбрать PRIMARY SMA и две SHADOW-стратегии.
4. Выполнить одиночный dry-run.
5. Убедиться, что таблица содержит три решения и роли верны.
6. Повторить цикл на той же свече: ожидается `already_processed`, но SHADOW не
   создают заявок.
7. Запустить непрерывный dry-run и кратко разорвать сеть.
8. Проверить `api_degraded`, затем автоматическое восстановление без повторной
   обработки свечи.
9. После 5–10 сессий назначить одну PRIMARY для Sandbox-исполнения с одним
   лотом.
10. Проверить полный стратегический цикл BUY → reconciliation → SELL.

## Тесты релиза

```powershell
pip install -r requirements-dev.txt
python -m pytest -q
```

Сборка v3.5.2 проходит **89 автоматических тестов**, включая:

- parity общего ядра стратегий;
- запрет заявок от SHADOW;
- сравнение сигналов;
- защиту смены PRIMARY;
- общий владелец позиции для разных таймфреймов;
- pending-order между таймфреймами;
- circuit breaker, recovery и reconciliation;
- русскую раскладку при вставке токена;
- миграцию SQLite schema v1 → v2;
- retry → recovery telemetry;
- отделение торгового решения от брокерской заявки;
- редактирование токена в логах;
- retry/recovery записи state-файла;
- сохранение прежнего state при окончательном отказе;
- восстановление принятой заявки после post-submit state failure без дубля;
- `WOULD_BUY`/`WOULD_SELL` и `order_was_sent`.

## Известные ограничения

- long-only, один инструмент на один исполнительный контур;
- нет шорта и плеча;
- `target_weight` масштабирует лимит лотов, но не рассчитывает риск в рублях;
- конечная реконструкция состояния SMA/Donchian использует увеличенное, но всё
  же конечное окно истории;
- ATR-stop проверяется по закрытию завершённой свечи;
- Sandbox не воспроизводит полностью очередь, реальный market impact и
  production-исполнение;
- исторические свечи акции не являются готовым total-return рядом;
- нет общего портфельного kill switch, секторных лимитов и корреляционного риска;
- shadow forward-run нужен для оценки устойчивости, а не доказательства будущей
  доходности.

## Структура проекта

```text
research_lab.py                    Streamlit Research Lab
desktop_gui.py                     нативный GUI и Sandbox
run_bot.py                         консольный Sandbox-робот
trading_robot/
  strategy.py                      общее научное ядро трёх стратегий
  strategy_runtime.py              StrategyDecision, PRIMARY/SHADOW и hashes
  bot.py                           исполнение, recovery и reconciliation
  tbank_sandbox.py                 REST-клиент только Sandbox
  backtest.py                      симулятор капитала и издержек
  validation.py                    grid search и walk-forward
  robustness.py                    stress и bootstrap
  diagnostics.py                   контролируемая заявка в один лот
  orders.py                        машина состояний заявки
  resilience.py                    persistent circuit breaker
  journal.py                       SQLite audit trail schema v2
  logging_setup.py                 ротация, уровни и редактирование секретов
  locking.py                       межпроцессные lock-файлы
tests/                             unit и integration tests
```
