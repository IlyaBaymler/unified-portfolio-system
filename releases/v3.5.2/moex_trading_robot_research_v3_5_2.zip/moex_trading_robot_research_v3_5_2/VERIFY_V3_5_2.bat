@echo off
setlocal
cd /d "%~dp0"
title Verify MOEX Robot v3.5.2

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] .venv not found. Run install_and_run_gui.bat first.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" -c "import trading_robot; assert trading_robot.__version__ == '0.3.5.2'; print('Version:', trading_robot.__version__)" || goto :fail
".venv\Scripts\python.exe" -m compileall -q trading_robot desktop_gui.py run_bot.py research_lab.py || goto :fail
".venv\Scripts\python.exe" -m pytest -q || goto :fail

echo.
echo Verification v3.5.2 completed successfully.
pause
exit /b 0

:fail
echo.
echo [ERROR] Verification v3.5.2 failed.
pause
exit /b 1
