# Обновление MOEX Trading Robot v3.5 → v3.5.1

## 1. Перед обновлением

1. Остановите dry-run или Sandbox Execution.
2. Закройте GUI.
3. Убедитесь, что во вкладке событий отсутствует незавершённый `pending_order`.
4. Сделайте копии:

```text
.env
robot_state.json
sandbox_diagnostic_state.json
trading_events.db
robot_gui.log
```

## 2. Установка hotfix

Распакуйте содержимое архива v3.5.1 непосредственно в папку установленной v3.5
и подтвердите замену файлов.

Hotfix не содержит и не заменяет:

```text
.env
.venv
robot_state.json
sandbox_diagnostic_state.json
trading_events.db
robot_gui.log
robot_debug.log
```

## 3. Проверка

Запустите:

```text
VERIFY_V3_5_1.bat
```

Ожидается:

```text
Version: 0.3.5.1
78 passed
Verification v3.5.1 completed successfully.
```

Затем запустите `run_gui.bat`. Заголовок окна:

```text
MOEX Research Robot v3.5.1
```

## 4. Миграция журнала

При первом открытии `trading_events.db` приложение автоматически добавляет
колонки schema v2. Старые события сохраняются. Отдельного конвертера не нужно.

Перед первым длительным запуском рекомендуется сохранить резервную копию базы.

## 5. Первый тест

1. Выполните одиночный dry-run.
2. Откройте «События v3.5.1».
3. Проверьте наличие `session/STARTED`, `decision/TRADE_DECISION`,
   `cycle/processed`, `session/STOPPED`.
4. Убедитесь, что для HOLD отсутствует `order/DECISION_CREATED`.
5. Запустите непрерывный dry-run на 60–90 минут.
6. Проверьте, что компактный лог не содержит полных словарей каждой проверки;
   подробности доступны в `robot_debug.log` и SQLite.
