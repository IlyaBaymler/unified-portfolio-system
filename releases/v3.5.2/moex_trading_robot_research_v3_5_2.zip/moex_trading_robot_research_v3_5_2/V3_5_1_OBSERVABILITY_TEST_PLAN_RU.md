# Протокол проверки v3.5.1

## A. Нормальная часовая сессия

Конфигурация остаётся неизменной относительно v3.5:

```text
SBER / TQBR / 1 час
PRIMARY SMA 20/50, hysteresis 0,2%
SHADOW Donchian 55/20, ATR 20 × 3
SHADOW Ensemble 50/200, momentum 126, breakout 100, votes 3
максимум 1 лот
```

Запустите непрерывный dry-run минимум на 70 минут.

Критерии:

- на новую свечу — один `decision/TRADE_DECISION` и три strategy decision;
- на повторные проверки — `cycle/already_processed`;
- INFO heartbeat не чаще одного раза за 30 минут;
- полный payload находится в `robot_debug.log`, но не в компактном логе;
- session ID одинаков для всех событий запуска;
- `cycle_duration_seconds` и `timings` заполнены.

## B. Восстановленный retry

Кратко разорвите сеть так, чтобы хотя бы одна внутренняя попытка завершилась
ошибкой, а следующая — успехом.

Ожидается:

```text
api/API_RETRY_SCHEDULED
api/API_RETRY_RECOVERED
cycle/processed или cycle/already_processed
```

`consecutive_failures` не увеличивается, если весь API-вызов в итоге успешен.

## C. Полный отказ цикла

Оставьте сеть отключённой дольше всех внутренних retry.

Ожидается:

```text
api/API_REQUEST_FAILED
incident/TRANSIENT_API_ERROR
cycle/api_degraded
pending_order отсутствует
```

После восстановления — новый session/cycle или продолжение с API AVAILABLE без
повторного решения по старой свече.

## D. Проверка ротации и секретов

- убедитесь, что токен отсутствует в `robot_gui.log` и `robot_debug.log`;
- большие журналы получают суффиксы `.1`, `.2` без аварии программы;
- экспорт CSV учитывает выбранные фильтры категории, severity и session ID.

## Критерий приёмки

- 0 заявок от SHADOW;
- 0 дублированных решений на одной свече;
- 0 токенов в файлах логов;
- все retry и деградации объяснимы по SQLite;
- компактный лог пригоден для чтения оператором без многостраничных словарей.
